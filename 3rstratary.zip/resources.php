<?php
include 'include/header.php';
?>
  
  <!--Start main Part-->
  <main class="main"> 
    
    <section class="inner_banner resources_banner">
     <div class="container">
        <div class="inner_text">
          <h2>Resources</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates enim fugiat soluta laboriosam laborum dolor dolore quae.</p>
        </div>
      </div>
      <div class="sec_scroll">
        <a class="scroll_sec" href="#div1"></a>
      </div>
    </section>

    <section class="section_wrapp_three" id="div1">
      <div class="container">
        <article class="row align-items-center">
          <aside class="col-md-6">
            <div class="section_wrapp_three_inner">
              <h2 class="title">Resources </h2>
              <p>As part of our commitment to helping you, we’ll update this page regularly with tools and resources to assist you along the way. From team management to leadership techniques and everything in between.</p>
              <p>If there’s a particular topic you’d like to hear more about, don’t hesitate to shout up and let us know </p>
            </div>
          </aside>
          <aside class="col-md-6">
            <div class="section_wrapp_three_img">
              <img src="images/resources1.jpg" alt="">
            </div>
          </aside>
        </article>
      </div>
    </section>

    <section class="resources">
      <div class="container">
        <h2 class="title">Placeholder for downloads</h2>
        <a href="#" class="btn_blue">Downloads</a>
      </div>
    </section>


  </main>
  <!--End main Part--> 
  
 <?php
  include 'include/footer.php';
  ?> 
