<?php
include 'include/header.php';
?>
  
  <!--Start main Part-->
  <main class="main"> 
    
    <section class="banner">
      <div class="container">
        <article class="row justify-content-center">
          <aside class="col-md-8">
            <div class="banner_text"> 
                <h2>Create a culture of excellence by engaging, empowering and retaining your people</h2>
            </div>
          </aside>
        </article>
      </div>
    </section>

    <section class="section_wrapp_one">
      <div class="container">
        <div class="section_wrapp_one_inner">
          <article class="row align-items-center">
            <aside class="col-md-6 pr-0">
              <div class="why_need_left">
                <p>Research shows that people who are more engaged in their daily work environment feel more motivated, actively deliver better results and are more attached to their jobs. Engaging your people and actively including them in the process gives them a feeling of being part of the business.</p>
                <p>Empowering them generates positive energy to tackle challenges, which in turn encourages open dialogue to ensure all voices are heard.</p>
                <p>With higher morale and by retaining your employees, you and your leadership team can concentrate on the primary challenges your business faces and not on internal issues related to people management.</p>
              </div>
            </aside>
            <aside class="col-md-6">
              <div class="why_need_right">
                <h2 class="title">Why You Need <span>Enabling Excellence</span></h2>
                <a href="#" class="btn_blue">Find Out More</a>
              </div>
            </aside>
          </article>
        </div>
      </div>
    </section>

    <section class="section_wrapp_two">
      <div class="container">
        <article class="row justify-content-end align-items-center">
          <aside class="col-md-6">
            <div class="section_wrapp_two_inner">
              <h2 class="title">What Is <span>Enabling Excellence</span></h2>
              <p>We are 3R strategy and we’re delighted to introduce our new project, Enabling Excellence. The project refers to a culture and a set of values which helps you inspire your Colleagues to be motivated and committed by building a culture of collaboration and trust.</p>
              <p>We’re passionate about ensuring you look after the people within your business at all levels by engaging them in your core values and supporting their development, all of which ultimately contribute to the overall success of the company itself.</p>
              <a href="#" class="btn_blue">Find Out More</a>
            </div>
          </aside>
        </article>
      </div>
    </section>
    
    <section class="section_wrapp_three">
      <div class="container">
        <article class="row align-items-center">
          <aside class="col-md-6">
            <div class="section_wrapp_three_inner">
              <h2 class="title">How Do You <span>Achieve Excellence</span></h2>
              <p>Through the use of journals, leadership training and on-going coaching, Enabling Excellence by 3R Strategy provides continuous development opportunities for your team of people, through regular and constructive discussions about performance and progress. </p>
              <p>Our journals assist you and your team in agreeing on individual goals and action plans using regular 1-2-1’s, discussing and improving individual and group performance, understanding individual needs to improve motivation and provides assistance in developing careers within your company.</p>
              <a href="#" class="btn_blue">Find Out More</a>
            </div>
          </aside>
          <aside class="col-md-6">
            <div class="section_wrapp_three_img">
              <img src="images/achieve-excellence.jpg" alt="">
            </div>
          </aside>
        </article>
      </div>
    </section>

    <section class="section_wrapp_four">
      <div class="container">
        <h3>A happy team leads to higher productivity and overall achievements. <br>It saves time on interviewing and training new people should someone leave. <br>It provides a sense of unity across the workforce.</h3>
        <h3>It’s time to Engage - Empower - Retain</h3>
      </div>
    </section>

    <section class="packages">
      <div class="container">
        <h2>Our Packages</h2>
      </div>
    </section>

    <section class="packages_inner">
      <div class="container">
        <article class="row">
          <aside class="col-md-4">
            <div class="packages_box">
              <div class="packages_content">
                <h2>Basic</h2>
                <h4>Employee journal</h4>
                <ul>
                  <li>Objective setting</li>
                  <li>Development goals</li>
                  <li>Personal feedback</li>
                  <li>Colleague feedback</li>
                </ul>
                <h4>Leader's guide</h4>
                <ul>
                  <li>How to carry out 1-2-1s</li>
                  <li>Objective setting guidance</li>
                  <li>Enabling Feedback: personal and colleague</li>
                  <li>Having difficult conversations</li>
                </ul>
              </div>
              <a href="#" class="btn_blue">GET A QUOTE</a>
            </div>
          </aside>
          <aside class="col-md-4">
            <div class="packages_box standard">
              <div class="packages_content">
                <h2>Standard</h2>
                <h3>All the benefits of Basic, plus:</h3>
                <div class="scrollbar" id="style-1">
                  <div class="force-overflow">
                    <h5>Leadership training</h5>
                    <h4>Workshop 1</h4>
                    <ul>
                      <li>Why does leadership matter?</li>
                      <li>What does effective leadership look like?</li>
                      <li>What kind of leader are you?</li>
                    </ul>
                    <h4>Workshop 2</h4>
                    <ul>
                      <li>Developing emotional intelligence</li>
                      <li>How to communicate effectively</li>
                      <li>Creating a culture of collaboration</li>
                      <li>Why and how to delegate</li>
                    </ul>
                    <h4>Workshop 3</h4>
                    <ul>
                      <li>Role modelling</li>
                      <li>Empowering individuals through coaching & mentoring</li>
                      <li>Empower individuals through feedback</li>
                      <li>Empower your team through Enabling Excellence</li>
                    </ul>
                  </div>
                </div>
              </div>
              <a href="#" class="btn_blue">GET A QUOTE</a>
            </div>
          </aside>
          <aside class="col-md-4">
            <div class="packages_box">
              <div class="packages_content">
                <h2>Enterprise</h2>
                <h3>All the benefits of Standard, plus:</h3>
                <h4>On-going support</h4>
                <ul>
                  <li>Monthly one-to-one sessions with your account manager</li>
                  <li>Bi-annual leadership coaching sessions</li>
                  <li>Development resources</li>
                  <li>Ongoing support</li>
                </ul>
              </div>
              <a href="#" class="btn_blue">GET A QUOTE</a>
            </div>
          </aside>
        </article>
      </div>
    </section>

    <section class="client_logo">
      <div class="container">
        <h2>Who We've Worked With</h2>
        <div class="logo_slider">
          <div class="slider_inner">
            <img src="images/logo1.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo2.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo3.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo4.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo5.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo6.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo7.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo8.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo9.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo10.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo11.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo12.jpg" alt="">
          </div>
          <div class="slider_inner">
            <img src="images/logo13.jpg" alt="">
          </div>
        </div>
      </div>
    </section>

  </main>
  <!--End main Part--> 
  
 <?php
  include 'include/footer.php';
  ?> 
