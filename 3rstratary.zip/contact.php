<?php
include 'include/header.php';
?>
  
  <!--Start main Part-->
  <main class="main"> 
    
    <section class="inner_banner contact_banner">
     <div class="container">
        <div class="inner_text">
          <h2>Contact </h2>
          <p>Let’s start enabling excellence for you and your team. There’s a variety of ways to get in touch with us.</p>
        </div>
      </div>
      <div class="sec_scroll">
        <a class="scroll_sec" href="#div1"></a>
      </div>
    </section>

    <section class="contact_wrapp" id="div1">
      <div class="container">
        <!-- <h2 class="title">Contact Us</h2>
        <p class="title_text">Let’s start enabling excellence for you and your team. There’s a variety of ways to get in touch with us. </p> -->
        <article class="row">
          <aside class="col-md-4">
            <div class="contact_address">
              <h4>You can find us at</h4>
              <p class="location">19-21 Hatton Garden, <br>London, EC1N 8BA</p>
            </div>
          </aside>
          <aside class="col-md-4">
            <div class="contact_address">
              <h4>You can contact us via</h4>
              <ul>
                <li>Phone : <a href="tel:0203 8806650">0203 8806650</a></li>
                <li>Email : <a href="mailto:hello@3rexcellence.com">hello@3rexcellence.com</a></li>
              </ul>
            </div>
          </aside>
          <aside class="col-md-4">
            <div class="contact_address">
              <h4>You can follow us on</h4>
              <ul class="social_fields">
                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
              </ul>
            </div>
          </aside>
        </article>
      </div>
    </section>

    <section class="get_in_touch">
      <div class="container">
        <h2 class="title">Get In Touch</h2>
        <article class="row justify-content-center">
          <aside class="col-md-10">
            <article class="row">
              <aside class="col-md-6">
                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" class="form-control">
                </div>
              </aside>
              <aside class="col-md-6">
                <div class="form-group">
                  <label for="Email">Email</label>
                  <input type="email" class="form-control">
                </div>
              </aside>
              <aside class="col-md-6">
                <div class="form-group">
                  <label for="Phone">Phone</label>
                  <input type="tel" class="form-control">
                </div>
              </aside>
              <aside class="col-md-6">
                <div class="form-group">
                  <label for="Subject">Subject</label>
                  <input type="text" class="form-control">
                </div>
              </aside>
              <aside class="col-md-12">
                <div class="form-group">
                  <label for="message">Message</label>
                  <textarea name="message" class="form-control"></textarea>
                </div>
              </aside>
            </article>
            <button class="btn_blue">Submit</button>
          </aside>
        </article>
      </div>
    </section>

    <section class="map">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.627298775018!2d-0.10844166043590307!3d51.52005331244297!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761b4dd465a431%3A0x151f6cf7fa68367d!2sHatton%20Garden%2C%20Holborn%2C%20London%2C%20UK!5e0!3m2!1sen!2sin!4v1585718285878!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </section>


  </main>
  <!--End main Part--> 
  
 <?php
  include 'include/footer.php';
  ?> 
