<?php
include 'include/header.php';
?>
  
  <!--Start main Part-->
  <main class="main"> 
    
    <section class="inner_banner services_banner">
      <div class="container">
        <div class="inner_text">
          <h2>Services</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates enim fugiat soluta laboriosam laborum dolor dolore quae.</p>
        </div>
      </div>
      <div class="sec_scroll">
        <a class="scroll_sec" href="#div1"></a>
      </div>
    </section>

    <section class="section_wrapp_three" id="div1">
      <div class="container">
        <article class="row align-items-center">
          <aside class="col-md-6">
            <div class="section_wrapp_three_inner">
              <h2 class="title">Services</h2>
              <p>From employee journals to leadership guides, training workshops to 1:1 coaching, our Enabling Excellence packages provide you with all the tools and resources you need to take your team to the next level of excellence. </p>
              <p>Check out our 3 packages below and get in touch if you have any questions! </p>
              <a href="contact.php" class="btn_blue">Get in Touch</a>
            </div>
          </aside>
          <aside class="col-md-6">
            <div class="section_wrapp_three_img">
              <img src="images/about2.jpg" alt="">
            </div>
          </aside>
        </article>
      </div>
    </section>

    <section class="packages">
      <div class="container">
        <h2>Our Packages</h2>
      </div>
    </section>

    <section class="packages_inner">
      <div class="container">
        <article class="row">
          <aside class="col-md-4">
            <div class="packages_box">
              <div class="packages_content">
                <h2>Basic</h2>
                <h4>Employee journal</h4>
                <ul>
                  <li>Objective setting</li>
                  <li>Development goals</li>
                  <li>Personal feedback</li>
                  <li>Colleague feedback</li>
                </ul>
                <h4>Leader's guide</h4>
                <ul>
                  <li>How to carry out 1-2-1s</li>
                  <li>Objective setting guidance</li>
                  <li>Enabling Feedback: personal and colleague</li>
                  <li>Having difficult conversations</li>
                </ul>
              </div>
              <a href="#" class="btn_blue">GET A QUOTE</a>
            </div>
          </aside>
          <aside class="col-md-4">
            <div class="packages_box standard">
              <div class="packages_content">
                <h2>Standard</h2>
                <h3>All the benefits of Basic, plus:</h3>
                <div class="scrollbar" id="style-1">
                  <div class="force-overflow">
                    <h5>Leadership training</h5>
                    <h4>Workshop 1</h4>
                    <ul>
                      <li>Why does leadership matter?</li>
                      <li>What does effective leadership look like?</li>
                      <li>What kind of leader are you?</li>
                    </ul>
                    <h4>Workshop 2</h4>
                    <ul>
                      <li>Developing emotional intelligence</li>
                      <li>How to communicate effectively</li>
                      <li>Creating a culture of collaboration</li>
                      <li>Why and how to delegate</li>
                    </ul>
                    <h4>Workshop 3</h4>
                    <ul>
                      <li>Role modelling</li>
                      <li>Empowering individuals through coaching & mentoring</li>
                      <li>Empower individuals through feedback</li>
                      <li>Empower your team through Enabling Excellence</li>
                    </ul>
                  </div>
                </div>
              </div>
              <a href="#" class="btn_blue">GET A QUOTE</a>
            </div>
          </aside>
          <aside class="col-md-4">
            <div class="packages_box">
              <div class="packages_content">
                <h2>Enterprise</h2>
                <h3>All the benefits of Standard, plus:</h3>
                <h4>On-going support</h4>
                <ul>
                  <li>Monthly one-to-one sessions with your account manager</li>
                  <li>Bi-annual leadership coaching sessions</li>
                  <li>Development resources</li>
                  <li>Ongoing support</li>
                </ul>
              </div>
              <a href="#" class="btn_blue">GET A QUOTE</a>
            </div>
          </aside>
        </article>
      </div>
    </section>


  </main>
  <!--End main Part--> 
  
 <?php
  include 'include/footer.php';
  ?> 
