<?php
include 'include/header.php';
?>
  
  <!--Start main Part-->
  <main class="main"> 
    
    <section class="inner_banner blog_banner">
     <div class="container">
        <div class="inner_text">
          <h2>Blog</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates enim fugiat soluta laboriosam laborum dolor dolore quae.</p>
        </div>
      </div>
      <div class="sec_scroll">
        <a class="scroll_sec" href="#div1"></a>
      </div>
    </section>

    <section class="blog_inner" id="div1">
      <div class="container">
        <article class="row">
          <aside class="col-md-9">
            <div class="blog_post">
              <div class="blog_img">
                <img src="images/bloginner.jpg" alt="">
              </div>
              <div class="blog_text">
                <h2>Lorem Ipsum is simply dummy text of the printing</h2>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
              </div>
              <div class="blog_bottom">
                <article class="row">
                  <aside class="col-md-6">
                    <ul>
                      <li><a href="#">By John</a></li>
                      <li><a href="#">31 march 2020</a></li>
                    </ul>
                  </aside>
                  <aside class="col-md-6">
                    <ul class="social_blog">
                      <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                      <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                      <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                  </aside>
                </article>
              </div>
            </div>
            <div id="comments">
              <h5>2 Comments</h5>
              <ul>
                <li>
                  <div class="avatar">
                    <a href="#"><img src="images/avatar.jpg" alt="">
                    </a>
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Add a comment..." id="comment">
                  </div>
                  <ul class="replied-to">
                    <li>
                      <div class="avatar">
                        <a href="#"><img src="images/avatar.jpg" alt="">
                        </a>
                      </div>
                      <div class="comment_right clearfix">
                        <div class="comment_info">
                          <h4>3rstrategy</h4>
                        </div>
                        <p>
                              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                            </p>
                            <p>
                              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                            </p>
                        <ul class="like">
                          <li><a href="#">Like</a></li>
                          <li><a href="#">Reply</a></li>
                          <li><i class="far fa-thumbs-up"></i> 32</li>
                          <li>25 September at 04:39</li>
                        </ul>
                        
                      </div>
                      <ul class="replied-to">
                        <li>
                          <div class="avatar">
                            <a href="#"><img src="images/avatar.jpg" alt="">
                            </a>
                          </div>
                          <div class="comment_right clearfix">
                            <div class="comment_info">
                              <h4>3rstrategy</h4>
                            </div>
                            <p>
                              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                            </p>
                            <p>
                              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                            </p>
                            <ul class="like">
                          <li><a href="#">Like</a></li>
                          <li><a href="#">Reply</a></li>
                          <li><i class="far fa-thumbs-up"></i> 32</li>
                          <li>25 September at 04:39</li>
                        </ul>
                          </div>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </aside>
          <aside class="col-md-3">
             <div class="widget p-0">
              <form>
                <div class="form-group">
                  <input type="text" name="search" id="search" class="form-control" placeholder="Search...">
                </div>
                <button type="submit" id="submit" class="search"> <i class="fas fa-search"></i></button>
              </form>
            </div>
            <div class="widget">
              <div class="main_title_3"> <span><em></em></span>
                <h2>Categories</h2>
                </div>
              <ul class="cats">
                <li><a href="#">Lorem ipsum dolor </a></li>
                <li><a href="#">Consectetur</a></li>
                <li><a href="#">Eiusmod tempor incididunt </a></li>
                <li><a href="#">Denouncing pleasure</a></li>
                <li><a href="#">Molestias excepturi </a></li>
                <li><a href="#">Beguiled and demoralized</a></li>
              </ul>
            </div>
            <!-- /widget -->
            <!-- /widget -->
            <div class="widget">
              <div class="main_title_3"> <span><em></em></span>
                <h2>Latest Post</h2>
                </div>
              <ul class="comments-list">
                <li>
                  <div class="alignleft">
                    <a href="#0"><img src="images/blog_thumb.jpg" alt=""></a>
                  </div>
                  <h6>Stratagy</h6>
                  <h3><a href="#" title="">Lorem ipsum dolor sit amet</a></h3>
                  <small>August 11, 2018</small>
                </li>
                <li>
                  <div class="alignleft">
                    <a href="#0"><img src="images/blog_thumb.jpg" alt=""></a>
                  </div>
                  <h6>Business</h6>
                  <h3><a href="#" title="">Lorem ipsum dolor sit amet</a></h3>
                  <small>August 11, 2018</small>
                </li>
                <li>
                  <div class="alignleft">
                    <a href="#0"><img src="images/blog_thumb.jpg" alt=""></a>
                  </div>
                  <h6>Stratagy</h6>
                  <h3><a href="#" title="">Lorem ipsum dolor sit amet</a></h3>
                  <small>August 11, 2018</small>
                </li>
              </ul>
          </aside>
        </article>
      </div>
    </section>


  </main>
  <!--End main Part--> 
  
 <?php
  include 'include/footer.php';
  ?> 
