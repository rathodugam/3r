<?php
include 'include/header.php';
?>
  
  <!--Start main Part-->
  <main class="main"> 
    
    <section class="inner_banner blog_banner">
     <div class="container">
        <div class="inner_text">
          <h2>Blog</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates enim fugiat soluta laboriosam laborum dolor dolore quae.</p>
        </div>
      </div>
      <div class="sec_scroll">
        <a class="scroll_sec" href="#div1"></a>
      </div>
    </section>

    <section class="blog" id="div1">
      <div class="container">
        <article class="row">
          <aside class="col-md-9">
            <article class="row">
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog1.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Business</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog2.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Stratagy</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog3.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Business</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog4.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Stratagy</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog5.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Business</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog6.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Stratagy</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog1.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Business</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog2.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Stratagy</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
              <aside class="col-md-4">
                <div class="blog_box">
                  <a href="blog-inner.php"><img src="images/blog3.jpg" alt=""></a>
                  <div class="blog_text">
                    <h6>Business</h6>
                    <a href="#"><h4>Lorem Ipsum Dolor Sit Amet</h4></a>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                    <h5>JUNE 14, 2019</h5>
                  </div>
                </div>
              </aside>
            </article>
          </aside>
          <aside class="col-md-3">
            <div class="widget p-0">
              <form>
                <div class="form-group">
                  <input type="text" name="search" id="search" class="form-control" placeholder="Search...">
                </div>
                <button type="submit" id="submit" class="search"> <i class="fas fa-search"></i></button>
              </form>
            </div>
            <div class="widget">
              <div class="main_title_3"> <span><em></em></span>
                <h2>Categories</h2>
                </div>
              <ul class="cats">
                <li><a href="#">Lorem ipsum dolor </a></li>
                <li><a href="#">Consectetur</a></li>
                <li><a href="#">Eiusmod tempor incididunt </a></li>
                <li><a href="#">Denouncing pleasure</a></li>
                <li><a href="#">Molestias excepturi </a></li>
                <li><a href="#">Beguiled and demoralized</a></li>
              </ul>
            </div>
            <!-- /widget -->
            <!-- /widget -->
            <div class="widget">
              <div class="main_title_3"> <span><em></em></span>
                <h2>Latest Post</h2>
                </div>
              <ul class="comments-list">
                <li>
                  <div class="alignleft">
                    <a href="#0"><img src="images/blog_thumb.jpg" alt=""></a>
                  </div>
                  <h6>Stratagy</h6>
                  <h3><a href="#" title="">Lorem ipsum dolor sit amet</a></h3>
                  <small>August 11, 2018</small>
                </li>
                <li>
                  <div class="alignleft">
                    <a href="#0"><img src="images/blog_thumb.jpg" alt=""></a>
                  </div>
                  <h6>Business</h6>
                  <h3><a href="#" title="">Lorem ipsum dolor sit amet</a></h3>
                  <small>August 11, 2018</small>
                </li>
                <li>
                  <div class="alignleft">
                    <a href="#0"><img src="images/blog_thumb.jpg" alt=""></a>
                  </div>
                  <h6>Stratagy</h6>
                  <h3><a href="#" title="">Lorem ipsum dolor sit amet</a></h3>
                  <small>August 11, 2018</small>
                </li>
              </ul>
            </div>
          </aside>
        </article>
      </div>
    </section>


  </main>
  <!--End main Part--> 
  
 <?php
  include 'include/footer.php';
  ?> 
