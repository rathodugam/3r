<?php
include 'include/header.php';
?>
  
  <!--Start main Part-->
  <main class="main"> 
    
    <section class="inner_banner team_banner">
     <div class="container">
        <div class="inner_text">
          <h2>Meet our Excellent Team</h2>
          <p>It’s always nice to put a face to a name right? Our team is highly experienced in all matters of training, leadership and HR. We work closely with you to ensure your excellence plan is suited to your organisation and provide regular support and advice to ensure you’re fully prepared to enable excellence for your team</p>
        </div>
      </div>
      <div class="sec_scroll">
        <a class="scroll_sec" href="#div1"></a>
      </div>
    </section>

    <section class="our_team" id="div1">
      <div class="container">
        <div class="team_member pt-0">
          <article class="row align-items-center">
            <aside class="col-md-6">
              <div class="member_img">
                <img src="images/member1.jpg" alt="">
              </div>
            </aside>
            <aside class="col-md-6">
              <div class="member_text">
                <h4>RAMEEZ KALEEM</h4>
                <h5>DIRECTOR</h5>
                <p>Rameez has almost 20 years of experience in HR and has worked with a wide range of companies across a number of sectors.</p>
                <p>Recent clients include: RSA Group, London Business School, Arriva Rail London and Paysafe. He has also done extensive work for several public sector organisations. Rameez has worked as a consultant for Willis Towers Watson and in-house in senior reward roles.</p>
                <p>He has worked across a wide range of projects, including job family design, pay structure and progression, employee recognition and performance management.</p>
              </div>
            </aside>
          </article>
        </div>
        <div class="team_member second">
          <article class="row align-items-center">
            <aside class="col-md-6">
              <div class="member_text">
                <h4>SARAH BROSCOMBE</h4>
                <h5>LEADERSHIP CONSULTANT</h5>
                <p>Sarah is a leadership specialist and co-active coach based in the UK.</p>
                <p>Educated at Oxford, she has worked on three continents in a range of people development roles. She is fascinated by the relationships between good leadership and generative listening, and between emotional intelligence and systems perspectives.</p>
                <p>Sarah splits her time between supporting leaders and other individuals to grow themselves, and helping groups and teams develop. She is an authorised user of the Leadership Development Framework, an Executive Coach with Experiential insight, and in-house coach and leadership team facilitator</p>
              </div>
            </aside>
            <aside class="col-md-6">
              <div class="member_img">
                <img src="images/member2.jpg" alt="">
              </div>
            </aside>
          </article>
        </div>
        <div class="team_member">
          <article class="row align-items-center">
            <aside class="col-md-6">
              <div class="member_img">
                <img src="images/member3.jpg" alt="">
              </div>
            </aside>
            <aside class="col-md-6">
              <div class="member_text">
                <h4>CENER DOGAN</h4>
                <h5>LEADERSHIP CONSULTANT</h5>
                <p>Cener Dogan specialises in inclusive leadership and team performance, with a particular focus on inclusive communication, constructive conversations and dialogue in teams, also in Women in Leadership and in cross-cultural and global (virtual) team management.</p>
                <p>Her work is anchored in people-oriented leadership, team cohesion and collaboration, as well as in sustainable relationships and trust followed by commitment, action and accountability to increase performance, meet strategic targets and stay commercially competitive​.</p>
                <p>She has trained and coached managers and senior leaders in multinational organisations across Europe.</p>
              </div>
            </aside>
          </article>
        </div>
        <div class="team_member second">
          <article class="row align-items-center">
            <aside class="col-md-6">
              <div class="member_text">
                <h4>TRACEY HODGSON</h4>
                <h5>CONSULTANT</h5>
                <p>Tracey has over 10 years experience of Compensation and Benefits, predominately working in house for the Hi-Tech, Pharmaceutical and Health Care industries, including AstraZeneca and Cargill.</p>
                <p>Specialising in European Reward process management including remuneration benchmarking, HR analytics and software implementation, partnering with HR and Line Managers to educate and provide governance on reward policy and practice.</p>
                <p>Tracey has worked alongside Willis Towers Watson, Mercer, Radford and Aon Hewitt.</p>
              </div>
            </aside>
            <aside class="col-md-6">
              <div class="member_img">
                <img src="images/member4.jpg" alt="">
              </div>
            </aside>
          </article>
        </div>
        <div class="team_member">
          <article class="row align-items-center">
            <aside class="col-md-6">
              <div class="member_img">
                <img src="images/member5.jpg" alt="">
              </div>
            </aside>
            <aside class="col-md-6">
              <div class="member_text">
                <h4>SARA GONZALEZ</h4>
                <h5>HR ADVISOR</h5>
                <p>Sara has over 5 years of experience in HR. She has worked on a wide range of projects, from analytics to recruitment and learning and development.</p>
                <p>She has designed and implemented systems to ensure compliance with policies and regulations.</p>
                <p>She has also created and delivered learning activities, managed professional development plans and performance reviews.</p>
              </div>
            </aside>
          </article>
        </div>
      </div>
    </section>


  </main>
  <!--End main Part--> 
  
 <?php
  include 'include/footer.php';
  ?> 
